# encoding: utf-8

"""
@author: liubo
@software: PyCharm
@file: transform.py
@time: 2016/12/28 10:53
@contact: ustb_liubo@qq.com
@annotation: tmp
"""

from loss import dummy_loss
import img_utils
import layers
import time
import os
import argparse
import pdb

from keras.models import load_model

parser = argparse.ArgumentParser(description='Fast Neural style transfer with Keras.')


parser.add_argument("--tv_weight", type=float, default=8.5e-5, help='Total Variation Weight')
parser.add_argument("--model_path",  type=str,)
parser.add_argument("--weight_path",  type=str,)
parser.add_argument("--output_image",  type=str,)
parser.add_argument("--content_path",  type=str,)
parser.add_argument("--img_size",  type=int,)

args = parser.parse_args()

''' Attributes '''
# style_name = str(args.style_name)
# content_path = str(args.content_img)
style_name = str('sunset_at_sea')

tv_weight = float(args.tv_weight)


content_path = args.content_path
output_image = args.output_image

''' Transform image '''

# model_path = "models/" + style_name + ".h5"
# weights_path = "weights/fastnet_%s.h5" % style_name

model_path = args.model_path
weights_path = args.weight_path


with open(model_path, "r") as f:
    string = f.read()
    model = load_model(
        model_path,
        dict(Denormalize=layers.Denormalize, VGGNormalize=layers.VGGNormalize,
             ReflectionPadding2D=layers.ReflectionPadding2D))
    model.compile("adam", dummy_loss)

    model.load_weights(weights_path)


size_multiple = 4 if len(model.layers) == 60 else 8 # 58 layers in shallow model, 62 in deeper model


img = img_utils.preprocess_image(content_path, load_dims=True, resize=True, img_width=args.img_size,
                                 img_height=args.img_size, size_multiple=size_multiple)

img /= 255.
width, height = img.shape[2], img.shape[3]

t1 = time.time()
# output = model.predict_on_batch(img)
output = model.predict(img)
t2 = time.time()

print("Saved image : %s" % output_image)
print("Prediction time : %0.2f seconds" % (t2 - t1))

img = output[0, :, :, :]
img = img_utils.deprocess_image(img)

img_utils.save_result(img, output_image, width, height)
