# encoding: utf-8

"""
@author: liubo
@software: PyCharm
@file: train.py
@time: 2016/12/28 10:53
@contact: ustb_liubo@qq.com
@annotation: tmp
"""

import os
from loss import dummy_loss
import models
import numpy as np
import argparse
import time
import img_utils
import warnings
from keras.optimizers import Adam
from keras.preprocessing.image import ImageDataGenerator
from keras import backend as K
import pdb


K.set_image_dim_ordering("th")

parser = argparse.ArgumentParser(description='Fast Neural style transfer with Keras.')
parser.add_argument('--style_reference_image_path', type=str, help='Path to the style reference image.')

parser.add_argument("--data_path", type=str, help="Path to training images")
parser.add_argument("--validation_img", type=str, default=None, help='Path to validation image')

parser.add_argument("--content_weight", type=float, default=1., help='Content weight')
parser.add_argument("--style_weight", type=float, default=10., help='Style weight')
parser.add_argument("--tv_weight", type=float, default=8.5e-5, help='Total Variation Weight')

# 先用256的调参数,然后可以换成大的图片
parser.add_argument("--image_size", dest="img_size", default=256, type=int, help='Output Image size')
parser.add_argument("--epochs", default=1, type=int, help='Number of epochs')
parser.add_argument("--nb_imgs", default=80000, type=int, help='Number of images per epoch')

parser.add_argument("--model_depth", default="shallow", type=str, help='Can be one of "shallow" or "wide"')
parser.add_argument("--model_width", default="thin", type=str, help='Can be one of "thin" or "wide"')

parser.add_argument("--pool_type", default="max", type=str, help='Pooling type')
parser.add_argument("--kernel_size", default=3, type=int, help='Kernel Size')
parser.add_argument("--val_checkpoint", type=int, default=-1, help='Check the output of network to a validation image')


args = parser.parse_args()
style_reference_image_path = args.style_reference_image_path
style_name = os.path.splitext(os.path.basename(style_reference_image_path))[0]

validation_img_path = args.validation_img

warnings.warn("Due to recent changes in how regularizers are handled in Keras, the code has been updated to support the new method.\n"
              "Please update your keras to the master branch to train properly.")

''' Attributes '''
# Dimensions of the input image
img_width = img_height = int(args.img_size)  # Image size needs to be same for gram matrix
nb_epoch = int(args.epochs)
num_iter = int(args.nb_imgs)  # Should be equal to number of images
train_batchsize = 1  # Using batchsize >= 2 results in unstable training

content_weight = float(args.content_weight)
style_weight = float(args.style_weight)
tv_weight = float(args.tv_weight)

val_checkpoint = int(args.val_checkpoint)
if val_checkpoint == -1:
    val_checkpoint = num_iter / 100 # Assuming full MS COCO Dataset has ~80k samples, validate every 400 samples

kernel_size = int(args.kernel_size)

pool_type = str(args.pool_type)
assert pool_type in ["max", "ave"], 'Pool Type must be either "max" or "ave"'
pool_type = 1 if pool_type == "ave" else 0

iteration = 0

model_depth = str(args.model_depth).lower()
assert model_depth in ["shallow", "deep"], 'model_depth must be one of "shallow" or "deep"'

model_width = str(args.model_width).lower()
assert model_width in ["thin", "wide"], 'model_width must be one of "thin" or "wide"'

size_multiple = 4 if model_depth == "shallow" else 8

''' Model '''

if not os.path.exists("models/"):
    os.makedirs("models/")

FastNet = models.FastStyleNet(img_width=img_width, img_height=img_height, kernel_size=kernel_size, pool_type=pool_type,
                              style_weight=style_weight, content_weight=content_weight, tv_weight=tv_weight,
                              model_width=model_width, model_depth=model_depth,
                              save_fastnet_model="models/%s_content-weight:%d_img-size:%d.h5" % (style_name, content_weight, args.img_size))

model = FastNet.create_model(style_name=None, train_mode=True, style_image_path=style_reference_image_path)

optimizer = Adam(beta_1=0.99)
model.compile(optimizer, dummy_loss)  # Dummy loss is used since we are learning from regularizes
print('Finished compiling fastnet model.')

datagen = ImageDataGenerator(rescale=1. / 255)

if K.image_dim_ordering() == "th":
    dummy_y = np.zeros((train_batchsize, 3, img_height, img_width))  # Dummy output, not used since we use regularizers to train
else:
    dummy_y = np.zeros((train_batchsize, img_height, img_width, 3)) # Dummy output, not used since we use regularizers to train

prev_improvement = -1
early_stop = False
validation_fastnet = None

sum_improvement = 0

for i in range(nb_epoch):
    print()
    print("Epoch : %d" % (i + 1))

    for x in datagen.flow_from_directory(args.data_path, class_mode=None, batch_size=train_batchsize,
                                         target_size=(img_width, img_height), shuffle=False):
        try:
            t1 = time.time()
            hist = model.fit([x, x.copy()], dummy_y, batch_size=train_batchsize, nb_epoch=1, verbose=0)

            iteration += train_batchsize
            loss = hist.history['loss'][0]

            if prev_improvement == -1:
                prev_improvement = loss

            improvement = (prev_improvement - loss) / prev_improvement * 100
            prev_improvement = loss
            sum_improvement += improvement

            t2 = time.time()
            print("Iter : %d / %d | Improvement : %0.2f percent |Time required : %0.2f seconds | Loss : %e" %
                 (iteration, num_iter, improvement, t2 - t1, loss))

            if iteration % val_checkpoint == 0:
                iter_path = style_name + "_epoch_%d_at_iteration_%d" % (i + 1, iteration)
                FastNet.save_fastnet_weights(iter_path, directory="val_weights_%s_content-weight:%d_img-size:%d_resize-style/" %(style_name, content_weight, args.img_size))

            if iteration >= num_iter:
                break

        except KeyboardInterrupt:
            print("Keyboard interrupt detected. Stopping early.")
            early_stop = True
            break

    iteration = 0

    if early_stop:
        break

FastNet.save_fastnet_weights(style_name, directory="weights/")

